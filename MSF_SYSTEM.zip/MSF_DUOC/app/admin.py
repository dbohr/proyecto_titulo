from django.contrib import admin
from .models import Rol, Region, Comuna, Medicamento, Receta, Usuario, Paciente, Cesfam, Despacho, Historial, Categoria

# Register your models here.
admin.site.register(Rol)
admin.site.register(Region)
admin.site.register(Comuna)
admin.site.register(Medicamento)
admin.site.register(Paciente)
admin.site.register(Receta)
admin.site.register(Usuario)
admin.site.register(Cesfam)
admin.site.register(Despacho)
admin.site.register(Historial)
admin.site.register(Categoria)
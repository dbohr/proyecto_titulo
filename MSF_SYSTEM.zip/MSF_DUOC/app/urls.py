from django.urls import path
from django.contrib.auth import views as auth_views
from .views import home, buscar_medicamento, despacho, recuperar_password, reportes,\
    listar_usuarios_rol, crear_usuario, administrar_rol, listar_medicamentos, agregar_medicamento,\
    modificar_medicamento, base, quienes_somos, registro, agregar_med, listar_med, modificar_med, solicitud_registro_user, listar_solicitudes, modificar_solicitudes, cesfam01, cesfam02, cesfam03, cesfam04, cesfam05, cesfam10, cesfam12, cesfam13




urlpatterns = [
    path('', home, name="home"),
    path('buscar_medicamento/', buscar_medicamento, name="buscar_medicamento"),
    path('despacho/', despacho, name="despacho"),
    path('recuperar_password/', recuperar_password, name="recuperar_password"),
    path('reportes/', reportes, name="reportes"),
    path('listar_usuarios_rol/', listar_usuarios_rol, name="listar_usuarios_rol"),
    path('crear_usuario/', crear_usuario, name="crear_usuario"),
    path('administrar_rol/', administrar_rol, name="administrar_rol"),
    path('listar_medicamentos/', listar_medicamentos, name="listar_medicamentos"),
    path('agregar_medicamento/', agregar_medicamento, name="agregar_medicamento"),
    path('modificar_medicamento/', modificar_medicamento, name="modificar_medicamento"),
    path('base/', base, name='base'),
    path('quienes_somos/', quienes_somos, name="quienes_somos"),
    path('registro/', registro, name="registro"),
    path('agregar_med', agregar_med, name="agregar_med"),
    path('listar_med', listar_med, name="listar_med"),
    path('modificar_med/<id>/', modificar_med, name="modificar_med"),
    path('solicitud_registro_user/', solicitud_registro_user, name="solicitud_registro_user"),
    path('listar_solicitudes/', listar_solicitudes, name="listar_solicitudes"),
    path('modificar_solicitudes<id>/', modificar_solicitudes, name="modificar_solicitudes"),
    path('cesfam01/', cesfam01, name="cesfam01"),
    path('cesfam02/', cesfam02, name="cesfam02"),
    path('cesfam03/', cesfam03, name="cesfam03"),
    path('cesfam04/', cesfam04, name="cesfam04"),
    path('cesfam05/', cesfam05, name="cesfam05"),
    path('cesfam10/', cesfam10, name="cesfam10"),
    path('cesfam12/', cesfam12, name="cesfam12"),
    path('cesfam13/', cesfam13, name="cesfam13"),   
    path('reset_password/',auth_views.PasswordResetView.as_view(template_name="registration/password_reset.html"),name='reset_password'),
    path('accounts/password_reset/done/',auth_views.PasswordResetDoneView.as_view(template_name='registration/password_reset_sent.html'),name='password_reset_done'),
    path('accounts/reset/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view(template_name='registration/pform.html'), name='password_reset_confirm'),
    path('accounts/reset/done/',auth_views.PasswordResetCompleteView.as_view(template_name='registration/password_reset_dones.html'),name='password_reset_complete'),




]

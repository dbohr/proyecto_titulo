from django.db import models 
from django.contrib.auth.models import AbstractUser

# Create your models here.



#Clase Rol
class Rol(models.Model):
    rol_id = models.AutoField(primary_key=True)
    nombre_rol = models.CharField(max_length=50, unique=True)
    descripcion = models.TextField()

    def __str__(self):
        return self.nombre_rol
    

#Clase Cetegoria
class Categoria(models.Model):
    categoria_id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.nombre
        
#Clase Region
class Region(models.Model):
    region_id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.nombre
        
#Clase Comuna        
class Comuna(models.Model):
    comuna_id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    region = models.ForeignKey(Region, on_delete=models.CASCADE)

    def __str__(self):
        return self.nombre

#Clase Medicamento
class Medicamento(models.Model):
    medicamento_id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    dosis = models.CharField(max_length=100)
    medicion = models.CharField(max_length=100)
    tipo = models.CharField(max_length=100)
    fecha_venc = models.DateField()
    lote = models.CharField(max_length=100)
    cantidad = models.IntegerField()
    laboratorio = models.CharField(max_length=100)
    lugar_almacenamiento = models.CharField(max_length=100)
    habilitado = models.BooleanField(default=True)
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)


    def __str__(self):
        return self.nombre, self.dosis, self.medicion, self.fecha_venc
    


#Clase Paciente
class Paciente(models.Model):
    paciente_id = models.AutoField(primary_key=True)
    nombre_completo = models.CharField(max_length=100)   
    rut = models.CharField(max_length=100)
    edad = models.IntegerField()
    sexo = models.CharField(max_length=100)   
    es_cronico = models.BooleanField(default=False)

    def _str_(self):
        return self.nombre_completo

#Clase Cesfam
class Cesfam(models.Model):
    cesfam_id = models.AutoField(primary_key=True)
    nombre_cesfam = models.CharField(max_length=100)
    direccion = models.CharField(max_length=100)
    comuna = models.ForeignKey(Comuna, on_delete=models.CASCADE)
    region = models.ForeignKey(Region, on_delete=models.CASCADE)


    def __str__(self):
        return self.nombre_cesfam 

#Clase Receta
class Receta(models.Model):
    folio = models.AutoField(primary_key=True)
    medico_asociado = models.CharField(max_length=100)
    diagnostico = models.CharField(max_length=200)
    medicamento = models.CharField(max_length=200)
    cantidad = models.IntegerField()
    dosis_total = models.CharField(max_length=200)
    paciente = models.ForeignKey(Paciente, on_delete=models.CASCADE)
    cesfam = models.ForeignKey(Cesfam, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.medico_asociado
      

#Clase Usuario para la creación de uno.    
class Usuario(models.Model):
    usuario_id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=200)
    rut = models.CharField(max_length=12, unique=True, null=False, blank=False)
    password1 = models.CharField(max_length=200)
    password2 = models.CharField(max_length=200)
    email = models.EmailField()
    telefono = models.CharField(max_length=12)
    fecha_nacimiento = models.DateField()
    estado = models.BooleanField(default=True)
    nombre_cesfam = models.ForeignKey(Cesfam, on_delete=models.CASCADE)
    nombre_rol = models.ForeignKey(Rol, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.nombre

#Clase Despacho
class Despacho(models.Model):
    despacho_id = models.AutoField(primary_key=True)
    paciente = models.ForeignKey(Paciente, on_delete=models.CASCADE)
    receta = models.ForeignKey(Receta, on_delete=models.CASCADE)
    medicamento = models.ForeignKey(Medicamento, on_delete=models.CASCADE)
    cesfam = models.ForeignKey(Cesfam, on_delete=models.CASCADE)
    fecha_emision = models.DateField()
    cantidad_medicamento = models.IntegerField()

    def _date_(self):
        return self.fecha_emision
    

#Clase Historial
class Historial(models.Model):
    historial_id = models.AutoField(primary_key=True)
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField()
    
    def __int__(self):
        return self.historial_id

#Solicitud Registro
class SolicitudRegistro(models.Model):
    solicitud_reg_id = models.AutoField(primary_key=True)
    nombre_completo = models.CharField(max_length=200)
    rut_solicitante = models.CharField(max_length=30)
    rol = models.CharField(max_length=50)
    estado = models.BooleanField(default=True)
    nota = models.TextField(max_length=300)
    nombre_cesfam = models.ForeignKey(Cesfam, on_delete=models.CASCADE)

    def get_estado_display(self):
        return "Pendiente" if self.estado else "Finalizado"

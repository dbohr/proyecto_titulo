from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Medicamento, SolicitudRegistro
from django.core.validators import MinValueValidator, MaxValueValidator
from django.core.exceptions import ValidationError
from datetime import date



class CustomUserCreationForm(UserCreationForm):
    pass


class CustomUserCreationForm(UserCreationForm):
    
    class Meta:
        model = User
        fields = ["username", "first_name", "last_name", "email","password1", "password2"]


class MedicamentoForm(forms.ModelForm):

    class Meta:
        model = Medicamento
        fields = '__all__'

        widgets = {
            "fecha_venc": forms.SelectDateWidget(
                empty_label=("Año", "Mes", "Día"),
            )
        }    

    #Validación de la cantidad de medicamento a ingresar sea mayor a cero
    cantidad = forms.IntegerField(
        validators=[
            MinValueValidator(limit_value=1, message="La cantidad debe ser mayor que cero."),
        ]
    )

    #Validación de la fecha de vencimiento del medicamento
    def clean_fecha_venc(self):
        fecha_venc = self.cleaned_data.get('fecha_venc')
        if fecha_venc and fecha_venc < date.today():
            raise ValidationError("La fecha de vencimiento debe ser en el futuro.")
        return fecha_venc



class SolicitudRegistroUserForm(forms.ModelForm):
    
    class Meta:
        model = SolicitudRegistro
        fields = '__all__'
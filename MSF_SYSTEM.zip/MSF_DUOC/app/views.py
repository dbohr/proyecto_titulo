from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from .models import Medicamento, Paciente, Receta, Despacho, SolicitudRegistro
from django.db import connection
from django.http import HttpResponse
from django.contrib.auth import authenticate, login
from .forms import CustomUserCreationForm, MedicamentoForm, SolicitudRegistroUserForm
from django.contrib import messages
from django.core.paginator import Paginator
from django.http import Http404

# Create your views here.
def base(request):
    return render(request, 'app/base.html')

# def footer(request):
#     return render(request, 'app/footer.html')

def home(request):
    return render(request, 'app/home.html')

def buscar_medicamento(request):
    return render(request, 'app/buscar_medicamento.html')

def despacho(request):
    if request.method == 'POST':
        rut_paciente = request.POST.get('rut_paciente')
        datos_paciente = request.POST.get('paciente_id')
        info_receta = request.POST.get('info_receta')
        fecha_emision = request.POST.get('fecha_emision')
        cantidad_medicamento = request.POST.get('cantidad_a_restar')
        medicamento_id = request.POST.get('medicamento_id')
        cantidad_a_restar = request.POST.get('cantidad_a_restar')
        cesfam_id = request.POST.get('cesfam_id')
        

        # Actualiza la base de datos
        with connection.cursor() as cursor:
            cursor.execute("EXEC Procedimiento_Despacho @fecha_emision = %s, @cantidad_medicamento = %s, @CesfamID = %s, @MedicamentoID = %s, @PacienteID = %s, @RecetaID = %s, @CantidadARestar = %s", 
                        [fecha_emision, cantidad_medicamento, cesfam_id, medicamento_id, datos_paciente, info_receta, cantidad_a_restar])
        try:
            # Busca el paciente por su rut
            paciente = Paciente.objects.get(rut=rut_paciente)
            # Obtén todos los medicamentos
            medicamentos = Medicamento.objects.all()
            # Busca la receta asociada a este paciente
            receta = Receta.objects.get(paciente=paciente)
            receta = Receta.objects.get(folio=receta.folio)
        except Paciente.DoesNotExist:
            paciente = None
            medicamentos = None
            receta = None

        except Receta.DoesNotExist:
            receta = None
        
        return render(request, 'app/despacho.html', {'paciente': paciente, 'medi': medicamentos, 'receta': receta})
        
    else:
        return render(request, 'app/despacho.html')


def recuperar_password(request):
    return render(request, 'app/recuperar_password.html')

def reportes(request):
    return render(request, 'app/reportes.html')

def listar_usuarios_rol(request):
    return render(request, 'app/listar_usuarios_rol.html')

def crear_usuario(request):
    return render(request, 'app/crear_usuario.html')

def administrar_rol(request):
    return render(request, 'app/administrar_rol.html')

def listar_medicamentos(request):
    medicamentos = Medicamento.objects.all()

    return render(request, 'app/listar_medicamentos.html', {'medicamentos': medicamentos})

def agregar_medicamento(request):
    return render(request, 'app/agregar_medicamento.html')

def modificar_medicamento(request):
    return render(request, 'app/modificar_medicamento.html')


def quienes_somos(request):
    return render(request, 'app/quienes_somos.html')

def registro(request):
    data = {
        'form': CustomUserCreationForm
    }

    if request.method == 'POST':
        formulario = CustomUserCreationForm(data=request.POST)
        if formulario.is_valid():
            formulario.save()
            user = authenticate(username=formulario.cleaned_data["username"], password=formulario.cleaned_data["password1"])
            login(request, user)
            return redirect(to="home")
        data["form"] = formulario

    return render(request, 'registration/registro.html',data)



def agregar_med(request):


    data = {
        'form': MedicamentoForm()
    }

    if request.method == 'POST':
        formulario = MedicamentoForm(data=request.POST)
        if formulario.is_valid():
            formulario.save()
            messages.success(request, "Medicamento agregado correctamente")
        else: 
            data["form"] = formulario


    return render(request, 'app/medicamento/agregar.html', data)

def listar_med(request):
    medicamentos = Medicamento.objects.all()
    page = request.GET.get('page', 1)

    try: 
        paginator = Paginator(medicamentos, 10)
        medicamentos = paginator.page(page)
    except:
        raise Http404


    data = {
        'entity': medicamentos,
        'paginator': paginator
    }

    return render(request, 'app/medicamento/listar.html', data)


def modificar_med(request, id):

    medicamento = get_object_or_404(Medicamento, medicamento_id=id)

    data = {
        'form': MedicamentoForm(instance=medicamento)
    }

    if request.method == 'POST':
        formulario = MedicamentoForm(data=request.POST, instance=medicamento)
        if formulario.is_valid():
            formulario.save()
            messages.success(request, "Modificado Correctamente")
            return redirect(to="listar_med")
        else: 
            data["form"] = formulario

    return render(request, 'app/medicamento/modificar.html', data)

def solicitud_registro_user(request):
    data = {
        'form': SolicitudRegistroUserForm
    }

    if request.method == 'POST':
        formulario = SolicitudRegistroUserForm(data=request.POST)
        if formulario.is_valid():
            formulario.save()
            messages.success(request, "Solicitud ingresada correctamente")
        else: 
            data["form"] = formulario

    return render(request, 'app/solicitud_registro_user.html',data)


def listar_solicitudes(request):

    solicitudes = SolicitudRegistro.objects.all()
    page = request.GET.get('page', 1)

    try: 
        paginator = Paginator(solicitudes, 10)
        solicitudes = paginator.page(page)
    except:
        raise Http404


    data = {
        'entity': solicitudes,
        'paginator': paginator
    }

    return render(request, 'app/listar_solicitudes.html', data)


def modificar_solicitudes(request, id):

    solicitudes = get_object_or_404(SolicitudRegistro, solicitud_reg_id=id)

    data = {
        'form': SolicitudRegistroUserForm(instance=solicitudes)
    }

    if request.method == 'POST':
        formulario = SolicitudRegistroUserForm(data=request.POST, instance=solicitudes)
        if formulario.is_valid():
            formulario.save()
            messages.success(request, "Modificado Correctamente")
            return redirect(to="listar_solicitudes")
        else: 
            data["form"] = formulario

    return render(request, 'app/medicamento/modificar.html', data)

def cesfam01(request):
    return render(request, 'app/cesfam/cesfam01.html')

def cesfam02(request):
    return render(request, 'app/cesfam/cesfam02.html')

def cesfam03(request):
    return render(request, 'app/cesfam/cesfam03.html')

def cesfam04(request):
    return render(request, 'app/cesfam/cesfam04.html')

def cesfam05(request):
    return render(request, 'app/cesfam/cesfam05.html')

def cesfam10(request):
    return render(request, 'app/cesfam/cesfam10.html')

def cesfam12(request):
    return render(request, 'app/cesfam/cesfam12.html')

def cesfam13(request):
    return render(request, 'app/cesfam/cesfam13.html')

$(document).ready(function() {
    // Cuando se hace clic en el botón "Buscar"
    $("#search-button").click(function() {
        var searchTerm = $("#search-input").val();

        // Realizar una solicitud AJAX para buscar medicamentos por nombre
        $.ajax({
            url: '/buscar_medicamentos/',
            data: {
                'search_term': searchTerm
            },
            dataType: 'json',
            success: function(data) {
                // Actualizar la tabla con los resultados de la búsqueda
                updateTable(data);
            }
        });
    });

    function updateTable(data) {
        // Limpia la tabla
        $("tbody").empty();

        // Rellena la tabla con los resultados de la búsqueda
        for (var i = 0; i < data.length; i++) {
            var medicamento = data[i];
            var row = "<tr>" +
                "<td>" + medicamento.nombre + "</td>" +
                "<td>" + medicamento.dosis + "</td>" +
                "<td>" + medicamento.medicion + "</td>" +
                "<td>" + medicamento.cantidad + "</td>" +
                "<td>" + medicamento.fecha_venc + "</td>" +
                "<td>" + medicamento.categoria + "</td>" +
                "<td><input type='checkbox' name='disponible' " + (medicamento.habilitado ? "checked" : "") + "></td>" +
                "</tr>";
            $("tbody").append(row);
        }
    }
});